package dev.hc.modules;

import dev.hc.Module;

public class CustomFov extends Module {
    public double fov = 120;
    public CustomFov() { super("custom_fov", "Render"); }
}
