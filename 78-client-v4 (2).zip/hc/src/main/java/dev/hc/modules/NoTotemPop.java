package dev.hc.modules;

import dev.hc.Module;

/** Menyembunyikan animasi item totem yang menutupi layar saat pop. */
public class NoTotemPop extends Module {
    public NoTotemPop() { super("no_totem_pop", "Render"); }
}
