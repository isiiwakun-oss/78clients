package dev.hc.modules;

import dev.hc.Module;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;

/** Bidik respawn anchor: isi dengan glowstone lalu meledakkan dengan item lain. */
public class AnchorMacro extends Module {
    private int cd;
    public AnchorMacro() { super("anchor_macro", "Combat"); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (cd-- > 0 || mc.currentScreen != null) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit)) return;
        var st = mc.world.getBlockState(hit.getBlockPos());
        if (!st.isOf(Blocks.RESPAWN_ANCHOR)) return;
        var inv = mc.player.getInventory();
        boolean empty = st.get(RespawnAnchorBlock.CHARGES) == 0;
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            boolean glow = inv.getStack(i).isOf(Items.GLOWSTONE);
            if (empty == glow) { slot = i; break; }
        }
        if (slot == -1) return;
        inv.setSelectedSlot(slot);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        cd = 2;
    }
}
