package dev.hc.modules;

import dev.hc.Module;
import dev.hc.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/** Kotak merah di pemain yang sedang dibidik. */
public class TargetEsp extends Module {
    public TargetEsp() { super("target_esp", "Render"); }

    @Override public void onRender(MinecraftClient mc, WorldRenderContext ctx) {
        Entity t = mc.targetedEntity;
        if (t instanceof PlayerEntity && t.isAlive()) RenderUtil.box(ctx, t.getBoundingBox(), 1f, 0f, 0f, 1f);
    }
}
