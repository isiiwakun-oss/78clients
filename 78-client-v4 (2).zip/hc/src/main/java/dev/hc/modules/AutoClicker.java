package dev.hc.modules;

import dev.hc.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import java.util.concurrent.ThreadLocalRandom;

/** Tahan tombol serang: klik otomatis ke entitas di crosshair dengan jeda acak. */
public class AutoClicker extends Module {
    private int wait;
    public AutoClicker() { super("autoclicker", "Combat"); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;
        if (wait-- > 0) return;
        if (mc.crosshairTarget instanceof EntityHitResult hit) {
            mc.interactionManager.attackEntity(mc.player, hit.getEntity());
            mc.player.swingHand(Hand.MAIN_HAND);
            wait = ThreadLocalRandom.current().nextInt(1, 4);
        }
    }
}
