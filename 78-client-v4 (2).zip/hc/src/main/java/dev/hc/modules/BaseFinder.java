package dev.hc.modules;

import dev.hc.Module;
import dev.hc.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;

/** Menandai chunk dengan banyak storage (indikasi base) dengan pilar tembus tembok. */
public class BaseFinder extends Module {
    public int threshold = 6;
    private final List<Vec3d> marks = new ArrayList<>();
    private int tick;
    public BaseFinder() { super("base_finder", "Render"); }

    @Override public void onTick(MinecraftClient mc) {
        if (tick++ % 40 != 0) return;
        List<Vec3d> found = new ArrayList<>();
        int rd = mc.options.getViewDistance().getValue();
        ChunkPos cp = mc.player.getChunkPos();
        for (int x = -rd; x <= rd; x++) for (int z = -rd; z <= rd; z++) {
            var chunk = mc.world.getChunkManager().getWorldChunk(cp.x + x, cp.z + z);
            if (chunk == null) continue;
            int n = 0;
            for (BlockEntity be : chunk.getBlockEntities().values()) if (StorageEsp.color(be) != null) n++;
            if (n >= threshold) found.add(new Vec3d(chunk.getPos().getStartX() + 8, 0, chunk.getPos().getStartZ() + 8));
        }
        marks.clear(); marks.addAll(found);
    }

    @Override public void onRender(MinecraftClient mc, WorldRenderContext ctx) {
        for (Vec3d m : marks) RenderUtil.line(ctx, new Vec3d(m.x, -64, m.z), new Vec3d(m.x, 320, m.z), 1f, 0.2f, 0.2f, 1f);
    }
}
