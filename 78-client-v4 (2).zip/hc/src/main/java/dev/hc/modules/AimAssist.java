package dev.hc.modules;

import dev.hc.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Menggeser bidikan pelan-pelan ke pemain terdekat yang sudah dekat crosshair. */
public class AimAssist extends Module {
    public double range = 4.5, fov = 70, speed = 4.0;
    public AimAssist() { super("aim_assist", "Combat"); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        PlayerEntity best = null;
        double bestDiff = fov;
        Vec3d eye = mc.player.getEyePos();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || mc.player.distanceTo(p) > range) continue;
            Vec3d d = p.getBoundingBox().getCenter().subtract(eye);
            float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90);
            double diff = Math.abs(MathHelper.wrapDegrees(yaw - mc.player.getYaw()));
            if (diff < bestDiff) { bestDiff = diff; best = p; }
        }
        if (best == null) return;
        Vec3d d = best.getBoundingBox().getCenter().subtract(eye);
        float ty = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90);
        float tp = (float) -Math.toDegrees(Math.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)));
        float dy = MathHelper.clamp(MathHelper.wrapDegrees(ty - mc.player.getYaw()), (float) -speed, (float) speed);
        float dp = MathHelper.clamp(tp - mc.player.getPitch(), (float) -speed, (float) speed);
        mc.player.setYaw(mc.player.getYaw() + dy);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + dp, -90f, 90f));
    }
}
