package dev.hc;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String name, category;
    public boolean enabled;
    protected Module(String name, String category) { this.name = name; this.category = category; }
    public void toggle() { enabled = !enabled; if (enabled) onEnable(); else onDisable(); }
    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient mc) {}
    public void onRender(MinecraftClient mc, WorldRenderContext ctx) {}
    /** Teks tombol di menu. */
    public String label() { return name + ": " + (enabled ? "ON" : "OFF"); }
    /** Nilai tambahan yang ikut disimpan ke config (opsional). */
    public String extra() { return null; }
    public void setExtra(String s) {}
}
