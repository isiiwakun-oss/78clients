package dev.hc.mixin;

import dev.hc.HC;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Clear View: overlay api/air/dalam blok. Target diberi nama string agar tidak patah kompilasi kalau class berubah. */
@Mixin(targets = "net.minecraft.client.gui.hud.InGameOverlayRenderer")
public abstract class InGameOverlayRendererMixin {
    @Inject(method = "renderOverlays", at = @At("HEAD"), cancellable = true, require = 0)
    private static void hc$all(CallbackInfo ci) { if (HC.CLEAR_VIEW.enabled) ci.cancel(); }

    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void hc$fire(CallbackInfo ci) { if (HC.CLEAR_VIEW.enabled) ci.cancel(); }

    @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void hc$water(CallbackInfo ci) { if (HC.CLEAR_VIEW.enabled) ci.cancel(); }

    @Inject(method = "renderInWallOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void hc$wall(CallbackInfo ci) { if (HC.CLEAR_VIEW.enabled) ci.cancel(); }
}
