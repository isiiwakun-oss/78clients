package dev.hc.modules;

import dev.hc.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/** Menurunkan opsi grafis yang berat; nilai asli disimpan (juga ke config) dan dipulihkan saat dimatikan. */
public class FpsBoost extends Module {
    private String saved;
    private boolean applied;

    public FpsBoost() { super("fps_boost", "Misc"); }

    @Override public void onEnable() { applied = false; }

    @Override public void onTick(MinecraftClient mc) {
        if (applied || mc.options == null) return;
        apply(mc.options);
        applied = true;
    }

    private void apply(GameOptions o) {
        if (saved == null) {
            saved = String.join("|",
                o.getGraphicsMode().getValue().name(),
                o.getParticles().getValue().name(),
                o.getCloudRenderMode().getValue().name(),
                String.valueOf(o.getViewDistance().getValue()),
                String.valueOf(o.getSimulationDistance().getValue()),
                String.valueOf(o.getEntityShadows().getValue()),
                String.valueOf(o.getBiomeBlendRadius().getValue()),
                String.valueOf(o.getEntityDistanceScaling().getValue()));
        }
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getViewDistance().setValue(Math.min(o.getViewDistance().getValue(), 8));
        o.getSimulationDistance().setValue(Math.min(o.getSimulationDistance().getValue(), 6));
        o.getEntityShadows().setValue(false);
        o.getBiomeBlendRadius().setValue(0);
        o.getEntityDistanceScaling().setValue(0.75);
    }

    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (saved != null && mc.options != null && applied) {
            try {
                String[] s = saved.split("\\|");
                GameOptions o = mc.options;
                o.getGraphicsMode().setValue(GraphicsMode.valueOf(s[0]));
                o.getParticles().setValue(ParticlesMode.valueOf(s[1]));
                o.getCloudRenderMode().setValue(CloudRenderMode.valueOf(s[2]));
                o.getViewDistance().setValue(Integer.parseInt(s[3]));
                o.getSimulationDistance().setValue(Integer.parseInt(s[4]));
                o.getEntityShadows().setValue(Boolean.parseBoolean(s[5]));
                o.getBiomeBlendRadius().setValue(Integer.parseInt(s[6]));
                o.getEntityDistanceScaling().setValue(Double.parseDouble(s[7]));
            } catch (Exception ignored) {}
        }
        saved = null; applied = false;
    }

    @Override public String extra() { return enabled ? saved : null; }
    @Override public void setExtra(String s) { saved = s; }
}
