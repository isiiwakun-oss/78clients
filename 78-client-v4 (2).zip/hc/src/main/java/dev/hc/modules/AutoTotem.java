package dev.hc.modules;

import dev.hc.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    public AutoTotem() { super("autototem", "Combat"); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        var inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            if (inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? i + 36 : i;
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, mc.player);
                return;
            }
        }
    }
}
