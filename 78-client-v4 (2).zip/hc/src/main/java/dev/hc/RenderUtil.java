package dev.hc;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

/**
 * Semua gambar ESP lewat sini. Layer-nya memakai pipeline garis vanilla dengan depth test DIMATIKAN,
 * jadi garis/kotak terlihat menembus tembok. Ini bagian paling sensitif versi (API render 1.21.11).
 */
public class RenderUtil {
    private static RenderLayer through;

    private static RenderLayer layer() {
        if (through == null) {
            try {
                RenderPipeline p = RenderPipelines.register(RenderPipeline.builder(RenderPipelines.RENDERTYPE_LINES_SNIPPET)
                    .withLocation(Identifier.of("hc", "pipeline/lines_through_walls"))
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .build());
                through = RenderLayer.of("hc_lines_through_walls", RenderSetup.builder(p).build());
            } catch (Throwable t) {
                through = RenderLayer.getLines(); // fallback: tidak tembus tembok
            }
        }
        return through;
    }

    public static void box(WorldRenderContext ctx, Box b, float r, float g, float bl, float a) {
        Vec3d cam = ctx.camera().getPos();
        VertexConsumer vc = ctx.consumers().getBuffer(layer());
        VertexRendering.drawBox(ctx.matrixStack(), vc, b.offset(-cam.x, -cam.y, -cam.z), r, g, bl, a);
    }

    public static void line(WorldRenderContext ctx, Vec3d from, Vec3d to, float r, float g, float b, float a) {
        Vec3d cam = ctx.camera().getPos();
        VertexConsumer vc = ctx.consumers().getBuffer(layer());
        Vec3d f = from.subtract(cam);
        int argb = ((int) (a * 255) << 24) | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
        VertexRendering.drawVector(ctx.matrixStack(), vc, new Vector3f((float) f.x, (float) f.y, (float) f.z), to.subtract(from), argb);
    }
}
