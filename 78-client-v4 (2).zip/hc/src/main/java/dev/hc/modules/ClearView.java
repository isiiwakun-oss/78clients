package dev.hc.modules;

import dev.hc.Module;

/** Menghilangkan overlay penghalang: api, air, dalam blok, pumpkin/powder snow, dan guncangan saat terkena damage. */
public class ClearView extends Module {
    public ClearView() { super("clear_view", "Render"); }
}
