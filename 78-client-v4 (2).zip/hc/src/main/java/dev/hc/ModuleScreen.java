package dev.hc;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.List;

/** Menu ramah sentuhan: tombol besar, paging, tidak butuh keyboard. */
public class ModuleScreen extends Screen {
    private int page;

    public ModuleScreen() { super(Text.literal("78 Client")); }

    private static Text label(Module m) {
        return Text.literal(m.label()).formatted(m.enabled ? Formatting.GREEN : Formatting.RED);
    }

    @Override
    protected void init() {
        List<Module> mods = HC.MODULES.all();
        int cols = width < 360 ? 2 : 3, bh = 26, gap = 6, bw = (width - 40 - gap * (cols - 1)) / cols;
        int rows = Math.max(1, (height - 70) / (bh + gap)), per = rows * cols;
        int pages = (mods.size() + per - 1) / per;
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < per; i++) {
            int idx = page * per + i;
            if (idx >= mods.size()) break;
            Module m = mods.get(idx);
            int x = 20 + (i % cols) * (bw + gap), y = 20 + (i / cols) * (bh + gap);
            addDrawableChild(ButtonWidget.builder(label(m), b -> { m.toggle(); b.setMessage(label(m)); })
                .dimensions(x, y, bw, bh).build());
        }
        int by = height - 36, w3 = (width - 40 - gap * 2) / 3;
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> { page--; clearAndInit(); })
            .dimensions(20, by, w3, bh).build()).active = page > 0;
        addDrawableChild(ButtonWidget.builder(Text.literal("Tutup"), b -> close())
            .dimensions(20 + w3 + gap, by, w3, bh).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> { page++; clearAndInit(); })
            .dimensions(20 + (w3 + gap) * 2, by, w3, bh).build()).active = page < pages - 1;
    }

    @Override public void removed() { HC.MODULES.save(); }
}
