package dev.hc.modules;

import dev.hc.Module;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;

/**
 * Mengganti tampilan Totem of Undying (tangan, inventory, animasi pop) dengan gaya buatan sendiri.
 * Tombol di menu: tiap tap pindah ke gaya berikutnya, setelah gaya terakhir kembali OFF.
 * Chat: ".totem" (gaya berikut), ".totem <nama>" (pilih langsung), ".totem off".
 */
public class CustomTotems extends Module {
    public static final String[] STYLES = {
        "gold", "emerald", "ruby", "amethyst", "ocean", "frost", "ender", "ash", "honey", "rose", "slime", "shade"
    };
    private static CustomTotems instance;
    private int idx = -1;

    public CustomTotems() { super("custom_totem", "Render"); instance = this; }

    public static Identifier modelFor(ItemStack stack) {
        CustomTotems m = instance;
        if (m == null || !m.enabled || m.idx < 0 || !stack.isOf(Items.TOTEM_OF_UNDYING)) return null;
        return Identifier.of("hc", "totem/" + STYLES[m.idx]);
    }

    @Override public void toggle() {
        idx++;
        if (idx >= STYLES.length) { idx = -1; enabled = false; } else enabled = true;
    }

    /** Dipanggil dari perintah chat. Mengembalikan teks status. */
    public static String command(String arg) {
        CustomTotems m = instance;
        if (m == null) return "";
        if (arg.isBlank()) { m.toggle(); }
        else if (arg.equalsIgnoreCase("off")) { m.idx = -1; m.enabled = false; }
        else {
            for (int i = 0; i < STYLES.length; i++) if (STYLES[i].equalsIgnoreCase(arg.trim())) { m.idx = i; m.enabled = true; return "Totem: " + STYLES[i]; }
            return "Gaya: " + String.join(", ", STYLES);
        }
        return m.enabled ? "Totem: " + STYLES[m.idx] : "Totem: default";
    }

    @Override public String label() { return enabled && idx >= 0 ? "totem: " + STYLES[idx] : "totem: OFF"; }
    @Override public String extra() { return String.valueOf(idx); }
    @Override public void setExtra(String s) { try { idx = Integer.parseInt(s); } catch (NumberFormatException ignored) {} }
}
