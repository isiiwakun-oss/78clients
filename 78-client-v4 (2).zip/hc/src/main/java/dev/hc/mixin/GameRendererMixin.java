package dev.hc.mixin;

import dev.hc.HC;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void hc$fov(CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(HC.modifyFov(cir.getReturnValue()));
    }

    /** No Totem Pop: lewati animasi item di layar. */
    @Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true, require = 0)
    private void hc$pop(CallbackInfo ci) { if (HC.NO_POP.enabled) ci.cancel(); }

    /** Clear View: tanpa guncangan kamera saat terkena damage. */
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void hc$hurt(CallbackInfo ci) { if (HC.CLEAR_VIEW.enabled) ci.cancel(); }
}
