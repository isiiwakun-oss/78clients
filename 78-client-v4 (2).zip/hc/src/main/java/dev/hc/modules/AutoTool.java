package dev.hc.modules;

import dev.hc.Module;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;

public class AutoTool extends Module {
    public AutoTool() { super("autotool", "Misc"); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit)) return;
        BlockState st = mc.world.getBlockState(hit.getBlockPos());
        var inv = mc.player.getInventory();
        int best = -1; float bs = 1f;
        for (int i = 0; i < 9; i++) {
            float s = inv.getStack(i).getMiningSpeedMultiplier(st);
            if (s > bs) { bs = s; best = i; }
        }
        if (best != -1) inv.setSelectedSlot(best);
    }
}
