package dev.hc.modules;

import dev.hc.Module;
import net.minecraft.client.MinecraftClient;

public class AutoWalk extends Module {
    public AutoWalk() { super("autowalk", "Misc"); }
    @Override public void onTick(MinecraftClient mc) { mc.options.forwardKey.setPressed(true); }
    @Override public void onDisable() { MinecraftClient.getInstance().options.forwardKey.setPressed(false); }
}
