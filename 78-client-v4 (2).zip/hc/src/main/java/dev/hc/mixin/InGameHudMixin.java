package dev.hc.mixin;

import dev.hc.HC;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Clear View: overlay layar penuh (pumpkin, powder snow). */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void hc$overlay(CallbackInfo ci) { if (HC.CLEAR_VIEW.enabled) ci.cancel(); }
}
