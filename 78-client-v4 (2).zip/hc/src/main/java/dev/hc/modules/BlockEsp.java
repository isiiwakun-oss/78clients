package dev.hc.modules;

import dev.hc.Module;
import dev.hc.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import java.util.ArrayList;
import java.util.List;

/** Ore/blok penting tembus tembok. Scan radius 20 tiap 1 detik. */
public class BlockEsp extends Module {
    record Hit(BlockPos pos, float[] col) {}
    private final List<Hit> hits = new ArrayList<>();
    private int tick;
    public BlockEsp() { super("block_esp", "Render"); }

    @Override public void onTick(MinecraftClient mc) {
        if (tick++ % 20 != 0) return;
        List<Hit> found = new ArrayList<>();
        BlockPos c = mc.player.getBlockPos();
        BlockPos.Mutable m = new BlockPos.Mutable();
        int R = 20;
        for (int x = -R; x <= R; x++) for (int y = -R; y <= R; y++) for (int z = -R; z <= R; z++) {
            m.set(c.getX() + x, c.getY() + y, c.getZ() + z);
            float[] col = color(mc.world.getBlockState(m).getBlock());
            if (col != null) found.add(new Hit(m.toImmutable(), col));
        }
        hits.clear(); hits.addAll(found);
    }

    @Override public void onRender(MinecraftClient mc, WorldRenderContext ctx) {
        for (Hit h : hits) RenderUtil.box(ctx, new Box(h.pos()), h.col()[0], h.col()[1], h.col()[2], 1f);
    }

    private float[] color(Block b) {
        if (b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE) return new float[]{0.3f, 1f, 1f};
        if (b == Blocks.ANCIENT_DEBRIS) return new float[]{0.6f, 0.3f, 0.1f};
        if (b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE) return new float[]{0.2f, 1f, 0.2f};
        if (b == Blocks.SPAWNER) return new float[]{1f, 0f, 0f};
        if (b == Blocks.RESPAWN_ANCHOR) return new float[]{0.8f, 0.2f, 1f};
        return null;
    }
}
