package dev.hc.modules;

import dev.hc.Module;

/** Aktif = mob hostile di-glow lewat EntityMixin. */
public class MobEsp extends Module {
    public MobEsp() { super("mob_esp", "Render"); }
}
