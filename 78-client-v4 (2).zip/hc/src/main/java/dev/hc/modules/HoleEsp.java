package dev.hc.modules;

import dev.hc.Module;
import dev.hc.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import java.util.ArrayList;
import java.util.List;

/** Lubang 1x1 yang dikelilingi bedrock (hijau) / obsidian (oranye). */
public class HoleEsp extends Module {
    record Hole(BlockPos pos, boolean bedrock) {}
    private final List<Hole> holes = new ArrayList<>();
    private int tick;
    public HoleEsp() { super("hole_esp", "Render"); }

    private static boolean safe(Block b) { return b == Blocks.BEDROCK || b == Blocks.OBSIDIAN; }

    @Override public void onTick(MinecraftClient mc) {
        if (tick++ % 10 != 0) return;
        List<Hole> found = new ArrayList<>();
        BlockPos c = mc.player.getBlockPos();
        for (int x = -8; x <= 8; x++) for (int y = -4; y <= 4; y++) for (int z = -8; z <= 8; z++) {
            BlockPos p = c.add(x, y, z);
            if (!mc.world.getBlockState(p).isAir() || !mc.world.getBlockState(p.up()).isAir()) continue;
            if (!safe(mc.world.getBlockState(p.down()).getBlock())) continue;
            boolean ok = true, allBed = mc.world.getBlockState(p.down()).getBlock() == Blocks.BEDROCK;
            for (Direction d : Direction.Type.HORIZONTAL) {
                Block b = mc.world.getBlockState(p.offset(d)).getBlock();
                if (!safe(b)) { ok = false; break; }
                if (b != Blocks.BEDROCK) allBed = false;
            }
            if (ok) found.add(new Hole(p, allBed));
        }
        holes.clear(); holes.addAll(found);
    }

    @Override public void onRender(MinecraftClient mc, WorldRenderContext ctx) {
        for (Hole h : holes) {
            Box b = new Box(h.pos()).contract(0.05, 0.9, 0.05);
            if (h.bedrock()) RenderUtil.box(ctx, b, 0.2f, 1f, 0.2f, 1f); else RenderUtil.box(ctx, b, 1f, 0.6f, 0f, 1f);
        }
    }
}
