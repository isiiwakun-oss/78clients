package dev.hc.modules;

import dev.hc.Module;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import java.nio.file.*;
import java.util.*;

/**
 * Macro dari file config/hc-macro.txt (edit lewat file manager HP). Satu baris = satu langkah:
 *   chat <teks atau /command>   |   slot <1-9>   |   use   |   wait <tick>
 * Dibuat otomatis dengan contoh kalau belum ada.
 */
public class Macros extends Module {
    private final ArrayDeque<String> queue = new ArrayDeque<>();
    private int wait;
    public Macros() { super("macro", "Misc"); }

    @Override public void onEnable() {
        queue.clear(); wait = 0;
        Path f = FabricLoader.getInstance().getConfigDir().resolve("hc-macro.txt");
        try {
            if (!Files.exists(f)) Files.writeString(f, "chat /home\nwait 20\nslot 3\nuse\n");
            for (String l : Files.readAllLines(f)) if (!l.isBlank()) queue.add(l.trim());
        } catch (Exception ignored) {}
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (wait > 0) { wait--; return; }
        String l = queue.poll();
        if (l == null) { enabled = false; return; }
        String[] p = l.split(" ", 2);
        String arg = p.length > 1 ? p[1] : "";
        try {
            switch (p[0]) {
                case "chat" -> { if (arg.startsWith("/")) mc.player.networkHandler.sendChatCommand(arg.substring(1)); else mc.player.networkHandler.sendChatMessage(arg); }
                case "slot" -> mc.player.getInventory().setSelectedSlot(Integer.parseInt(arg) - 1);
                case "use" -> mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                case "wait" -> wait = Integer.parseInt(arg);
            }
        } catch (Exception ignored) {}
    }
}
