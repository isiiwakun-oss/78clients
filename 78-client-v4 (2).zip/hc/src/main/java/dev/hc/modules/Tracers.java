package dev.hc.modules;

import dev.hc.Module;
import dev.hc.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Tracers extends Module {
    public Tracers() { super("tracers", "Render"); }

    @Override
    public void onRender(MinecraftClient mc, WorldRenderContext ctx) {
        float pt = mc.getRenderTickCounter().getTickProgress(true);
        Vec3d start = ctx.camera().getPos().add(Vec3d.fromPolar(ctx.camera().getPitch(), ctx.camera().getYaw()).multiply(0.5));
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            RenderUtil.line(ctx, start, p.getLerpedPos(pt).add(0, p.getHeight() / 2, 0), 1f, 1f, 1f, 1f);
        }
    }
}
