package dev.hc;

import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.file.Path;
import java.util.*;

public class ModuleManager {
    private final List<Module> list = new ArrayList<>();
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("hc.properties");

    public void add(Module m) { list.add(m); }
    public List<Module> all() { return list; }

    public void load() {
        Properties p = new Properties();
        try (InputStream in = new FileInputStream(file.toFile())) { p.load(in); } catch (IOException ignored) { return; }
        for (Module m : list) {
            String ex = p.getProperty(m.name + ".extra");
            if (ex != null) m.setExtra(ex);
            if (Boolean.parseBoolean(p.getProperty(m.name, "false"))) { m.enabled = true; m.onEnable(); }
        }
    }

    public void save() {
        Properties p = new Properties();
        for (Module m : list) {
            p.setProperty(m.name, String.valueOf(m.enabled));
            if (m.extra() != null) p.setProperty(m.name + ".extra", m.extra());
        }
        try (OutputStream out = new FileOutputStream(file.toFile())) { p.store(out, "78 Client"); } catch (IOException ignored) {}
    }
}
