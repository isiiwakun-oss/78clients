package dev.hc.modules;

import dev.hc.Module;

/** Memperbesar margin bidikan ke pemain (dipakai EntityMixin). */
public class HitBox extends Module {
    public double expand = 0.3;
    public HitBox() { super("hitbox", "Combat"); }
}
