package dev.hc.mixin;

import dev.hc.modules.CustomTotems;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Mengganti model item Totem of Undying di sisi klien (tangan, inventory, dan animasi pop). */
@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
    @Inject(method = "get", at = @At("RETURN"), cancellable = true, require = 0)
    private void hc$totemModel(ComponentType<?> type, CallbackInfoReturnable<Object> cir) {
        if (type != DataComponentTypes.ITEM_MODEL) return;
        Identifier id = CustomTotems.modelFor((ItemStack) (Object) this);
        if (id != null) cir.setReturnValue(id);
    }
}
