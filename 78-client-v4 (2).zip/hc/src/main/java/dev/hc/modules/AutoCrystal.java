package dev.hc.modules;

import dev.hc.Module;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Dasar: hancurkan crystal dekat target, dan pasang crystal di obsidian/bedrock terdekat ke target. Tanpa hitung damage. */
public class AutoCrystal extends Module {
    private int cd;
    public AutoCrystal() { super("autocrystal", "Combat"); }

    @Override
    public void onTick(MinecraftClient mc) {
        PlayerEntity target = null; double bd = 100;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive()) continue;
            double d = mc.player.squaredDistanceTo(p);
            if (d < bd) { bd = d; target = p; }
        }
        if (target == null) return;

        for (EndCrystalEntity c : mc.world.getEntitiesByClass(EndCrystalEntity.class, mc.player.getBoundingBox().expand(5), e -> true)) {
            if (mc.player.distanceTo(c) <= 4.5 && c.distanceTo(target) <= 7) {
                mc.interactionManager.attackEntity(mc.player, c);
                mc.player.swingHand(Hand.MAIN_HAND);
                return;
            }
        }
        if (cd-- > 0) return;

        Hand hand = Hand.MAIN_HAND;
        if (mc.player.getOffHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
        else {
            int slot = -1;
            for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).isOf(Items.END_CRYSTAL)) { slot = i; break; }
            if (slot == -1) return;
            mc.player.getInventory().setSelectedSlot(slot);
        }

        BlockPos best = null; double bestD = 36;
        BlockPos c = mc.player.getBlockPos();
        for (int x = -4; x <= 4; x++) for (int y = -3; y <= 3; y++) for (int z = -4; z <= 4; z++) {
            BlockPos p = c.add(x, y, z);
            var b = mc.world.getBlockState(p).getBlock();
            if (b != Blocks.OBSIDIAN && b != Blocks.BEDROCK) continue;
            if (!mc.world.getBlockState(p.up()).isAir() || !mc.world.getBlockState(p.up(2)).isAir()) continue;
            if (mc.player.squaredDistanceTo(Vec3d.ofCenter(p)) < 4) continue; // jangan terlalu dekat diri sendiri
            double d = target.squaredDistanceTo(Vec3d.ofCenter(p));
            if (d < bestD) { bestD = d; best = p; }
        }
        if (best == null) return;
        mc.interactionManager.interactBlock(mc.player, hand, new BlockHitResult(Vec3d.ofCenter(best).add(0, 0.5, 0), Direction.UP, best, false));
        cd = 2;
    }
}
