package dev.hc.modules;

import dev.hc.Module;

public class Zoom extends Module {
    public double factor = 4.0;
    public Zoom() { super("zoom", "Render"); }
}
