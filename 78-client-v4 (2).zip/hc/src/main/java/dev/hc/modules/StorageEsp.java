package dev.hc.modules;

import dev.hc.Module;
import dev.hc.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;

/** Storage ESP tembus tembok (lihat RenderUtil). */
public class StorageEsp extends Module {
    public StorageEsp() { super("storage_esp", "Render"); }

    @Override
    public void onRender(MinecraftClient mc, WorldRenderContext ctx) {
        int rd = mc.options.getViewDistance().getValue();
        ChunkPos cp = mc.player.getChunkPos();
        for (int x = -rd; x <= rd; x++) for (int z = -rd; z <= rd; z++) {
            var chunk = mc.world.getChunkManager().getWorldChunk(cp.x + x, cp.z + z);
            if (chunk == null) continue;
            for (BlockEntity be : chunk.getBlockEntities().values()) {
                float[] c = color(be);
                if (c != null) RenderUtil.box(ctx, new Box(be.getPos()), c[0], c[1], c[2], 1f);
            }
        }
    }

    public static float[] color(BlockEntity be) {
        if (be instanceof EnderChestBlockEntity) return new float[]{0.6f, 0f, 1f};
        if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) return new float[]{1f, 0.6f, 0f};
        if (be instanceof ShulkerBoxBlockEntity) return new float[]{1f, 0.3f, 0.8f};
        if (be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity) return new float[]{0.6f, 0.6f, 0.6f};
        if (be instanceof AbstractFurnaceBlockEntity) return new float[]{0.7f, 0.7f, 0.7f};
        if (be instanceof MobSpawnerBlockEntity) return new float[]{1f, 0f, 0f};
        if (be instanceof BrewingStandBlockEntity) return new float[]{0.3f, 0.8f, 1f};
        return null;
    }
}
