package dev.hc.mixin;

import dev.hc.HC;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true, require = 0)
    private void hc$glow(CallbackInfoReturnable<Boolean> cir) {
        if (HC.glowColor((Entity) (Object) this) != -1) cir.setReturnValue(true);
    }

    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true, require = 0)
    private void hc$color(CallbackInfoReturnable<Integer> cir) {
        int c = HC.glowColor((Entity) (Object) this);
        if (c != -1) cir.setReturnValue(c);
    }

    /** HitBox: margin pick lebih besar untuk pemain. */
    @Inject(method = "getTargetingMargin", at = @At("HEAD"), cancellable = true, require = 0)
    private void hc$margin(CallbackInfoReturnable<Float> cir) {
        float m = HC.hitboxMargin((Entity) (Object) this);
        if (m > 0) cir.setReturnValue(m);
    }
}
