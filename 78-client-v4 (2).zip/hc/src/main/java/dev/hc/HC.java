package dev.hc;

import dev.hc.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class HC implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    public static final PlayerEsp PLAYER_ESP = new PlayerEsp();
    public static final MobEsp MOB_ESP = new MobEsp();
    public static final HitBox HITBOX = new HitBox();
    public static final Zoom ZOOM = new Zoom();
    public static final CustomFov CUSTOM_FOV = new CustomFov();
    public static final ClearView CLEAR_VIEW = new ClearView();
    public static final NoTotemPop NO_POP = new NoTotemPop();
    private static boolean openGui;

    @Override
    public void onInitializeClient() {
        // Render
        MODULES.add(new StorageEsp());
        MODULES.add(new BlockEsp());
        MODULES.add(new HoleEsp());
        MODULES.add(PLAYER_ESP);
        MODULES.add(MOB_ESP);
        MODULES.add(new TargetEsp());
        MODULES.add(new Tracers());
        MODULES.add(new BaseFinder());
        MODULES.add(new Fullbright());
        MODULES.add(ZOOM);
        MODULES.add(CUSTOM_FOV);
        MODULES.add(new CustomTotems());
        MODULES.add(CLEAR_VIEW);
        MODULES.add(NO_POP);
        // Combat
        MODULES.add(new KillAura());
        MODULES.add(new AimAssist());
        MODULES.add(new Triggerbot());
        MODULES.add(new AutoClicker());
        MODULES.add(HITBOX);
        MODULES.add(new AutoTotem());
        MODULES.add(new AutoCrystal());
        MODULES.add(new AnchorMacro());
        // Misc
        MODULES.add(new FpsBoost());
        MODULES.add(new AutoTool());
        MODULES.add(new AutoWalk());
        MODULES.add(new Macros());
        MODULES.load();
        Hud.register();

        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("hc", "main"));
        KeyBinding guiKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.hc.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));

        // Android: ketik ".gui" di chat, atau map tombol layar ke Right Shift.
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> {
            String t = msg.trim();
            if (t.equalsIgnoreCase(".gui")) { openGui = true; return false; }
            if (t.toLowerCase().startsWith(".totem")) {
                String r = CustomTotems.command(t.substring(6).trim());
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.player != null) mc.player.sendMessage(net.minecraft.text.Text.literal("[78] " + r), false);
                MODULES.save();
                return false;
            }
            return true;
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (guiKey.wasPressed()) openGui = true;
            if (openGui && mc.currentScreen == null) { openGui = false; mc.setScreen(new ModuleScreen()); }
            if (mc.player == null || mc.world == null) return;
            for (Module m : MODULES.all()) if (m.enabled) m.onTick(mc);
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            for (Module m : MODULES.all()) if (m.enabled) m.onRender(mc, ctx);
        });
    }

    public static int glowColor(Entity e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || e == mc.player || !mc.isOnThread()) return -1;
        if (e instanceof PlayerEntity) {
            if (!PLAYER_ESP.enabled) return -1;
            double d = mc.player.distanceTo(e);
            return d < 8 ? 0xFF3333 : d < 24 ? 0xFFAA00 : 0x55FF55;
        }
        if (MOB_ESP.enabled && e instanceof HostileEntity) return 0xFF55FF;
        return -1;
    }

    public static float hitboxMargin(Entity e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || !HITBOX.enabled || e == mc.player || !(e instanceof PlayerEntity) || !mc.isOnThread()) return -1;
        return (float) HITBOX.expand;
    }

    public static float modifyFov(float f) {
        if (ZOOM.enabled) return f / (float) ZOOM.factor;
        if (CUSTOM_FOV.enabled) return (float) CUSTOM_FOV.fov;
        return f;
    }
}
