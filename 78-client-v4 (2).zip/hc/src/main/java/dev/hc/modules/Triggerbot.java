package dev.hc.modules;

import dev.hc.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public class Triggerbot extends Module {
    public Triggerbot() { super("triggerbot", "Combat"); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null || mc.player.getAttackCooldownProgress(0f) < 1f) return;
        if (mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof PlayerEntity p && p.isAlive()) {
            mc.interactionManager.attackEntity(mc.player, p);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }
}
