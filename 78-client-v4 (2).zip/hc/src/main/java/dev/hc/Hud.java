package dev.hc;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

public class Hud {
    public static void register() {
        HudElementRegistry.addLast(Identifier.of("hc", "hud"), (ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;
            int y = 4;
            ctx.drawTextWithShadow(mc.textRenderer, "78 Client  (.gui)", 4, y, 0xFF55FFFF);
            for (Module m : HC.MODULES.all()) {
                if (!m.enabled) continue;
                y += 10;
                ctx.drawTextWithShadow(mc.textRenderer, m.name, 4, y, 0xFFFFFFFF);
            }
        });
    }
}
