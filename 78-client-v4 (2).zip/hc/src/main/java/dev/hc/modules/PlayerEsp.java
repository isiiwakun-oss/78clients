package dev.hc.modules;

import dev.hc.Module;

/** Aktif = pemain di-glow lewat EntityMixin (warna menurut jarak). */
public class PlayerEsp extends Module {
    public PlayerEsp() { super("player_esp", "Render"); }
}
