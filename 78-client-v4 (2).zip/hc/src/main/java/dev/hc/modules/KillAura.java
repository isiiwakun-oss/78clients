package dev.hc.modules;

import dev.hc.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

public class KillAura extends Module {
    public double range = 3.5;
    public KillAura() { super("killaura", "Combat"); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player.getAttackCooldownProgress(0f) < 1f) return;
        PlayerEntity best = null;
        double bd = range * range;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive()) continue;
            double d = mc.player.squaredDistanceTo(p);
            if (d < bd) { bd = d; best = p; }
        }
        if (best == null) return;
        mc.interactionManager.attackEntity(mc.player, best);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
